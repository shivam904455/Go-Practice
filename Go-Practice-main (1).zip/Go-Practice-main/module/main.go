package main

import (

"fmt"

"github.com/gorilla/mux"
)

func main() {
	fmt.Println("testng module...")
      _ = mux.Route{}
}
 //fmt.println("testing module...")
//  _=mux.rout{}