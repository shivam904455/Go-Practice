package main

import "fmt"

func main() {
	num1 := 20
	num2 := 20
	add := num1 + num2
	fmt.Println(add)
}
