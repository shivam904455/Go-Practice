package main

import "fmt"

func main() {
	fmt.Println("testing go commands...")
}
